interface ICategoryShared {
  name: string;
}

export type ICategoryFrontend = ICategoryShared;
export type ICategoryBackend = ICategoryShared;
