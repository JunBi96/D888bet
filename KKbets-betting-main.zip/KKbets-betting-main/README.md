# KKbets Betting Site

<img width="768" src="https://github.com/Ryczko/KKbets-betting/assets/51440879/bcba8fed-67ab-48ea-aa4b-81cd015aff00">

KKbets is a website that allows you to bet on sports events using virtual currency.
Place your bets and fight for the best place in the ranking.

Check application demo here: https://kkbets.onrender.com/

## 🧐 Features

- Login/registration using Google
- Sports betting
- Collecting points
- Overview of the bets placed
- Editing a profile
- User ranking
- Live chat
- Daily bonuses
- Admin page

## 🚀 Technologies

- React
- Typescript
- Node
- Express
- Redux
- Passport.js
- Material UI
- React-router
- Styled-components
- Socket.io
