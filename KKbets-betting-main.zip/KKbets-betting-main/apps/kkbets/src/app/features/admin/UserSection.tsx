export default function UserSection() {
  return (
    <div style={{ minHeight: '100px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      Place for users management
    </div>
  );
}
