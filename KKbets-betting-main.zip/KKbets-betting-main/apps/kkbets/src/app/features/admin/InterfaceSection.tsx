export default function InterfaceSection() {
  return (
    <div style={{ minHeight: '100px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      Place for interface management
    </div>
  );
}
