import styled from 'styled-components';

export const StyledRanking = styled.div`
  h1 {
    margin: 16px 0 70px;
    font-size: 25px;
    text-align: center;
  }
`;
