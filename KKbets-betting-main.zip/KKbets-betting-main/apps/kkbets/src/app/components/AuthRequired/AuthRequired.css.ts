import styled from 'styled-components';

export const StyledAuthRequired = styled.div`
  text-align: center;
`;
